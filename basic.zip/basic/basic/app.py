from flask import Flask, Response, render_template
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import tensorflow as tf
import mediapipe as mp
import sklearn
import matplotlib.pyplot as plt
import os 
import time
import pyttsx3  # Import the text-to-speech library

# Initialize text-to-speech engine


app = Flask(__name__)

import threading

engine_running = False

# Define a function to speak the entire sentence
def speak_sentence(sentence):
    engine = pyttsx3.init()
    # Speak the sentence
    engine.say(sentence)
    engine.runAndWait()
    engine.stop()
    # engine.iterate()  # Iterate the engine loop to process speech
    # engine.runAndWait()
# Load pre-trained model (replace with your model filename)
model = load_model('C:/Users/91810/OneDrive/Desktop/basic/basic/model/my_model.keras')
mp_holistic = mp.solutions.holistic # Holistic model
from mediapipe.python.solutions.face_mesh_connections import FACEMESH_TESSELATION
#Path for exported data, numpy arrays
DATA_PATH = os.path.join('Data') 
    
    # Actions that we try to detect
actions = np.array(['Coffee','Good','Hello','How are you','I','Morning','One','Please','sorry','Thank you'])

    # Ten npy worth of data
no_sequences = 10
 
    # npy are going to be 10 frames in length
sequence_length = 10

    # Folder start
start_folder = 0
colors = [
    (255, 0, 0),    # Red
    (0, 255, 0),    # Green
    (0, 0, 255),    # Blue
    (255, 255, 0),  # Cyan
    (255, 0, 255),  # Magenta
    (0, 255, 255),  # Yellow
    # Add more colors as needed
]
mp_drawing = mp.solutions.drawing_utils # Drawing utilities
def mediapipe_detection(image, model):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) # COLOR CONVERSION BGR 2 RGB
    image.flags.writeable = False                  # Image is no longer writeable
    results = model.process(image)                 # Make prediction
    image.flags.writeable = True                   # Image is now writeable 
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) # COLOR COVERSION RGB 2 BGR
    return image, results

def draw_landmarks(image, results):
    mp_drawing.draw_landmarks(image, results.face_landmarks, mp_holistic.FACEMESH_TESSELATION) # Draw face connections
    mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS) # Draw pose connections
    mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS) # Draw left hand connections
    mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS) # Draw right hand connections

def draw_styled_landmarks(image, results):
    # Draw face connections
    mp_drawing.draw_landmarks(image, results.face_landmarks, mp_holistic.FACEMESH_TESSELATION, 
                                mp_drawing.DrawingSpec(color=(80,110,10), thickness=1, circle_radius=1), 
                                mp_drawing.DrawingSpec(color=(80,256,121), thickness=1, circle_radius=1)
                                ) 

    #Draw pose connections
    mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
                                mp_drawing.DrawingSpec(color=(80,22,10), thickness=2, circle_radius=4), 
                                mp_drawing.DrawingSpec(color=(80,44,121), thickness=2, circle_radius=2)
                                ) 
    #Draw left hand connections
    mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS, 
                                mp_drawing.DrawingSpec(color=(121,22,76), thickness=2, circle_radius=4), 
                                mp_drawing.DrawingSpec(color=(121,44,250), thickness=2, circle_radius=2)
                                ) 
    #Draw right hand connections  
    mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS, 
                                mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=4), 
                                mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2)
                            ) 
    
cap = cv2.VideoCapture(0)

def extract_keypoints(results):
    pose = np.array([[res.x, res.y, res.z, res.visibility] for res in results.pose_landmarks.landmark]).flatten() if results.pose_landmarks else np.zeros(33*4)
    face = np.array([[res.x, res.y, res.z] for res in results.face_landmarks.landmark]).flatten() if results.face_landmarks else np.zeros(468*3)
    lh = np.array([[res.x, res.y, res.z] for res in results.left_hand_landmarks.landmark]).flatten() if results.left_hand_landmarks else np.zeros(21*3)
    rh = np.array([[res.x, res.y, res.z] for res in results.right_hand_landmarks.landmark]).flatten() if results.right_hand_landmarks else np.zeros(21*3)
    return np.concatenate([pose, face, lh, rh])

def preprocess_image(image):
    # Preprocessing steps tailored to your model (e.g., resizing, normalization)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (224, 224))  # Example model input size
    normalized = resized / 255.0  # Example normalization
    return normalized.reshape((1, 224, 224, 1))  # Example model input shape

def prob_viz(res, actions, input_frame, colors):
    output_frame = input_frame.copy()
    color_count = len(colors)  # Get the number of available colors
    for num, prob in enumerate(res):
        color_index = num % color_count  # Use modulo to avoid index out of range
        cv2.rectangle(output_frame, (0, 60 + num * 40), (int(prob * 100), 30 + num * 40), colors[color_index], -1)
        if num < len(actions):  # Check if action exists for this num
            cv2.putText(output_frame, actions[num], (0, 85 + num * 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
    return output_frame

def detect_and_predict():
        # 1. New detection variables
    sequence = []
    sentence = []
    predictions = []
    threshold = 0.7
    flag_speak = False 
    cap = cv2.VideoCapture(0)
    # Set mediapipe model 

    with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        while cap.isOpened():

            # Read feed
            ret, frame = cap.read()

            # Make detections
            image, results = mediapipe_detection(frame, holistic)
            # cv2.waitKey(2000)
            print(results)
            
            # Draw landmarks
            draw_styled_landmarks(image, results)
            draw_styled_landmarks(frame, results)
            
            # 2. Prediction logic
            keypoints = extract_keypoints(results)
            sequence.append(keypoints)
            sequence = sequence[-10:]
            
            if len(sequence) == 10:
                res = model.predict(np.expand_dims(sequence, axis=0))[0]
                predictions.append(np.argmax(res))
                action = actions[np.argmax(res)]
               
                if np.unique(predictions[-10:])[0] == np.argmax(res) and res[np.argmax(res)] > threshold:
                    if len(sentence) > 0 and action != sentence[-1]:
                        sentence.append(action)
                        # if not flag_speak:  # Check if text is being spoken currently
                        #     flag_speak = True  # Set flag to indicate text is being spoken
                        #     print(sentence)
                        threading.Thread(target=speak_sentence, args=(action,)).start()
                    elif len(sentence) == 0:
                        sentence.append(action)
                        threading.Thread(target=speak_sentence, args=(action,)).start()
                        # if not flag_speak:  # Check if text is being spoken currently
                        #     flag_speak = True  # Set flag to indicate text is being spoken
                        #     threading.Thread(target=speak_sentence, args=(' '.join(sentence),)).start()
                else:
                    flag_speak = False  # Reset flag if no new text is added   
                if len(sentence) > 5: 
                        sentence = sentence[-5:]
                
            #3. Viz logic
                if np.unique(predictions[-10:])[0]==np.argmax(res): 
                    if res[np.argmax(res)] > threshold: 
                        
                        if len(sentence) > 0: 
                            if actions[np.argmax(res)] != sentence[-1]:
                                sentence.append(actions[np.argmax(res)])
                                # engine.say(actions[np.argmax(res)])  # Speak the action
                                # engine.runAndWait()  # Wait for the speech to finish
                        else:
                            sentence.append(actions[np.argmax(res)])
                            # engine.say(actions[np.argmax(res)])  # Speak the action
                            # engine.runAndWait()  # Wait for the speech to finish
                   

                # Viz probabilities
                image = prob_viz(res, actions, image, colors)
                frame = prob_viz(res, actions, frame, colors)
            cv2.rectangle(image, (0,0), (640, 40), (245, 117, 16), -1)
            cv2.putText(image, ' '.join(sentence), (3,30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)
            
            cv2.rectangle(frame, (0,0), (640, 40), (245, 117, 16), -1)
            cv2.putText(frame, ' '.join(sentence), (3,30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            # Show to screen
            # cv2.imshow('OpenCV Feed', image)
            # yield cv2.imencode('.jpg',frame)[1].tobytes()

            # Break gracefully
        #     if cv2.waitKey(10) & 0xFF == ord('q'):
        #         break
        # cap.release()
        # cv2.destroyAllWindows()

@app.route('/')
def index():
    return render_template('index.html')  # Render HTML template

@app.route('/video_feed')
def video_feed():
    return Response(detect_and_predict(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)
